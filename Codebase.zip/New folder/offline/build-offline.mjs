// Bundles the shared catalogue + retrieval logic and the vanilla UI into a
// single self-contained offline .html file (images inlined as data URLs).
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const out = process.argv[2] || "/mnt/documents/ornativa-concierge-offline.html";

const result = await Bun.build({
  entrypoints: [resolve(here, "demo.js")],
  target: "browser",
  minify: true,

});
if (!result.success) {
  console.error(result.logs);
  process.exit(1);
}
const js = await result.outputs[0].text();

// Inline every catalogue image as a base64 data URL so the file works offline.
const SKUS = ["R101","R102","N201","N202","E301","E302","B401","B402","P501","P502"];
const images = {};
for (const sku of SKUS) {
  const buf = readFileSync(resolve(here, "../src/assets/" + sku + ".jpg"));
  images[sku] = "data:image/jpeg;base64," + buf.toString("base64");
}
const imagesScript = "window.__ORNATIVA_IMAGES__=" + JSON.stringify(images) + ";";
const css = readFileSync(resolve(here, "demo.css"), "utf8");

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Ornativa Concierge — Offline Jewellery Catalogue Demo</title>
<meta name="description" content="Offline demo of the Ornativa Jewels concierge: browse the ten-piece Hyderabad catalogue and ask about price, metal, weight and stock. Works fully in the browser." />
<style>
${css}
</style>
</head>
<body>
<div id="app"></div>
<script>
${imagesScript}
</script>
<script>
${js}
</script>
</body>
</html>
`;

mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, html);
console.log("wrote", out, (html.length / 1024).toFixed(0) + " KB");
